import { Routes, Route } from 'react-router-dom'
import Nav from './components/Nav'
import Protected from './components/Protected'
import Login from './pages/Login'
import Register from './pages/Register'
import Properties from './pages/Properties'
import PropertyView from './pages/PropertyView'
import Dashboard from './pages/Dashboard'
import Leases from './pages/Leases'
import Payments from './pages/Payments'
import Tickets from './pages/Tickets'

export default function App() {
  return (
    <>
      <Nav />
      <Routes>
        <Route path="/" element={<Properties />} />
        <Route path="/property/:id" element={<PropertyView />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/dashboard"
          element={
            <Protected>
              <Dashboard />
            </Protected>
          }
        />
        <Route
          path="/leases"
          element={
            <Protected>
              <Leases />
            </Protected>
          }
        />
        <Route
          path="/payments"
          element={
            <Protected>
              <Payments />
            </Protected>
          }
        />
        <Route
          path="/tickets"
          element={
            <Protected>
              <Tickets />
            </Protected>
          }
        />
      </Routes>
    </>
  )
}
