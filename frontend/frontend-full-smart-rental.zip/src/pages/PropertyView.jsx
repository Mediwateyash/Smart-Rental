import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import api from '../api/axios'

export default function PropertyView() {
  const { id } = useParams()
  const [property, setProperty] = useState(null)

  useEffect(() => {
    api.get(`/properties/${id}`).then(res => setProperty(res.data))
  }, [id])

  if (!property) return <div style={{ padding: 20 }}>Loading...</div>

  return (
    <div style={{ maxWidth: 800, margin: '20px auto' }}>
      <h2>{property.title}</h2>
      <p>
        {property.address}, {property.city}
      </p>
      <p>
        Rent: ₹{property.rent}/month | {property.bedrooms} BR /{' '}
        {property.bathrooms} BA
      </p>
      <p>
        Owner: {property.owner?.name} ({property.owner?.email})
      </p>
    </div>
  )
}
