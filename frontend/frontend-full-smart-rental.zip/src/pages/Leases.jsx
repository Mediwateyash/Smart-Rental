import { useEffect, useState } from 'react'
import api from '../api/axios'

export default function Leases() {
  const [items, setItems] = useState([])

  useEffect(() => {
    api.get('/leases/me').then(res => setItems(res.data))
  }, [])

  return (
    <div style={{ maxWidth: 800, margin: '20px auto' }}>
      <h2>My Leases</h2>
      <ul>
        {items.map(l => (
          <li
            key={l._id}
            style={{ padding: 12, border: '1px solid #eee', margin: '8px 0' }}
          >
            {l.property?.title} — {l.status}
          </li>
        ))}
      </ul>
    </div>
  )
}
