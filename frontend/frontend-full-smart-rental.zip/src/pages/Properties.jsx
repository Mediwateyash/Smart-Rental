import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/axios'

export default function Properties() {
  const [items, setItems] = useState([])

  useEffect(() => {
    api.get('/properties').then(res => setItems(res.data))
  }, [])

  return (
    <div style={{ maxWidth: 900, margin: '20px auto' }}>
      <h2>Available Properties</h2>
      <ul>
        {items.map(p => (
          <li
            key={p._id}
            style={{ padding: 12, border: '1px solid #eee', margin: '8px 0' }}
          >
            <strong>{p.title}</strong> — ₹{p.rent}/month — {p.city}
            <div>
              <Link to={`/property/${p._id}`}>View</Link>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
