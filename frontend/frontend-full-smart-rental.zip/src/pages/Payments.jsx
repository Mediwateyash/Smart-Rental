import { useEffect, useState } from 'react'
import api from '../api/axios'

export default function Payments() {
  const [items, setItems] = useState([])

  useEffect(() => {
    api.get('/payments').then(res => setItems(res.data))
  }, [])

  return (
    <div style={{ maxWidth: 800, margin: '20px auto' }}>
      <h2>Payments</h2>
      <ul>
        {items.map(p => (
          <li
            key={p._id}
            style={{ padding: 12, border: '1px solid #eee', margin: '8px 0' }}
          >
            ₹{p.amount} — {p.status}{' '}
            {p.dueDate && `(due ${new Date(p.dueDate).toLocaleDateString()})`}
          </li>
        ))}
      </ul>
    </div>
  )
}
