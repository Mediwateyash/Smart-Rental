import { useEffect, useState } from 'react'
import api from '../api/axios'

export default function Dashboard() {
  const [user, setUser] = useState(null)

  useEffect(() => {
    api.get('/auth/me').then(res => setUser(res.data))
  }, [])

  return (
    <div style={{ maxWidth: 800, margin: '20px auto' }}>
      <h2>Dashboard</h2>
      {user && (
        <p>
          Welcome, {user.name}! Role: <strong>{user.role}</strong>
        </p>
      )}
      <ul>
        <li>
          View your <a href="/leases">Leases</a>
        </li>
        <li>
          View <a href="/payments">Payments</a>
        </li>
        <li>
          Manage <a href="/tickets">Maintenance Tickets</a>
        </li>
      </ul>
    </div>
  )
}
