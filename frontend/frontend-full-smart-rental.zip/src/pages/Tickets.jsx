import { useEffect, useState } from 'react'
import api from '../api/axios'

export default function Tickets() {
  const [items, setItems] = useState([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')

  useEffect(() => {
    api.get('/tickets').then(res => setItems(res.data))
  }, [])

  const submit = async e => {
    e.preventDefault()
    const { data } = await api.post('/tickets', { title, description })
    setItems([data, ...items])
    setTitle('')
    setDescription('')
  }

  return (
    <div style={{ maxWidth: 800, margin: '20px auto' }}>
      <h2>Maintenance Tickets</h2>

      <form onSubmit={submit} style={{ margin: '12px 0' }}>
        <input
          placeholder="Title"
          value={title}
          onChange={e => setTitle(e.target.value)}
          style={{ width: '100%', padding: 8, margin: '8px 0' }}
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={e => setDescription(e.target.value)}
          style={{ width: '100%', padding: 8, margin: '8px 0' }}
        />
        <button>Create Ticket</button>
      </form>

      <ul>
        {items.map(t => (
          <li
            key={t._id}
            style={{ padding: 12, border: '1px solid #eee', margin: '8px 0' }}
          >
            <strong>{t.title}</strong> — {t.status}
          </li>
        ))}
      </ul>
    </div>
  )
}
