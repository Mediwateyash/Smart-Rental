import { Link } from 'react-router-dom'

export default function Nav() {
  const token = localStorage.getItem('token')

  const logout = () => {
    localStorage.removeItem('token')
    window.location.href = '/login'
  }

  return (
    <nav
      style={{
        display: 'flex',
        gap: '12px',
        padding: '12px',
        borderBottom: '1px solid #eee'
      }}
    >
      <Link to="/">Properties</Link>
      <Link to="/dashboard">Dashboard</Link>
      <Link to="/leases">Leases</Link>
      <Link to="/payments">Payments</Link>
      <Link to="/tickets">Tickets</Link>

      <span style={{ marginLeft: 'auto' }}>
        {token ? <button onClick={logout}>Logout</button> : <Link to="/login">Login</Link>}
      </span>
    </nav>
  )
}
